# ESC: Dataset for Environmental Sound Classification

This repository contained a subset of the whole dataset (ESC-10) and has been merged with the main [ESC-50 repo](https://github.com/karoldvl/ESC-50).